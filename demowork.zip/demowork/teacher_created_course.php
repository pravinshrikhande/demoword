<?php
	/* Template Name: Not Create Course */ 
	global $wpdb;
	?>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
	<div class="wrap">
		<h2>Teachers Created Course</h2>
	</div>
	<style>
	td { height: 50px;}
	td.highlight {
        //font-weight: bold;
        color: blue;
    }
	table.dataTable.select tbody tr,
	table.dataTable thead th:first-child {
	  cursor: pointer;
	}
	#geton{
		margin-left:11px;
	}
	.btn {
				display: inline-block;
				padding: 9px 12px;
				padding-top: 6px;
				margin-bottom: 0;
				font-size: 13px;
				line-height: 16px;
				color: #5e5e5e;
				text-align: center;
				vertical-align: middle;
				cursor: pointer;
				background-color: #d1dade;
				-webkit-border-radius: 3px;
				-webkit-border-radius: 3px;
				-webkit-border-radius: 3px;
				background-image: none !important;
				border: none;
				text-shadow: none;
				box-shadow: none;
				transition: all 0.12s linear 0s !important;
				font: 13px/13px "Helvetica Neue",Helvetica,Arial,sans-serif;
				}

				.btn-success {
				color: #fff;
				background-color: #2295d8;
				border-color: #4cae4c;
				}
	</style>
	<?php 
	if(isset($_POST['submitDelete'])){
			   $getrowvalue = explode(',',$_POST['rowvalue']);
				$i = count($getrowvalue);
				if(!empty($_POST['rowvalue']))
				{
					for($j=0;$j<$i;$j++){
						$emailtech = get_userdata($getrowvalue[$j]);
						$to = trim($emailtech->user_email);
						$teacher = trim($emailtech->display_name);
						$sendmail = emailCreate($to , $teacher); 
						$sendon[$j] = "Success :  ".$to;
						if($j+1 == $i)
						{
							$message = $sendon;
							//print_r($message);exit;
						}
					}
				}
                else{
					$message = "Please Select Checkbox";
				}				
		    
		}
		?>
<?php 
		/* -------------------------- Email Start----------------------*/
			function emailCreate($to , $teacher){
					  $message = '';
					  $admin_email = get_option('admin_email');
					  $admin_site = get_option('blogname');

					  $adminto = $admin_email;

					  $headers= '';
					  $headers .= 'From: '.$admin_site.' <'.$admin_email.'>' . "\r\n";
					  $headers .= "Reply-To: ". $admin_email . "\r\n";
					  $headers .= "MIME-Version: 1.0\r\n";
					  $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

					   global $wpdb;
						$results = $wpdb->get_results("select * from ".$wpdb->prefix ."ext_page where id ='4'");
						  $subject = $results[0]->page_name;
						  $message.= "Dear ".$teacher.",\r\n";
						  $message.="<br/>";
						  $message.= $results[0]->Description."\r\n";
					  $sentmail = wp_mail($to,$subject,$message,$headers);
			}
			/* -------------------------- Email End ----------------------*/		
?>

	<article id="post-1234565" >
	    <h2>Teachers Created Course</h2>
		<?php if(!empty($message) && is_array($message)){
        foreach ($message as $key => $value) { ?>
          <div class="updated notice">
              <p><?= $value; ?></p>
          </div>
      <?php  }
      } else if(!empty($message) && is_string($message)) { ?>
        <div class="updated error">
            <p><?= $message; ?></p>
        </div>
      <?php  } ?>
	       <p id="msgdiv"></p>
			<div class="entry-content">
			<form method="post" action="">
			<span class="pull-right">
			    <div class="btn btn-success" style="color:#fff;">
					<a href="?page=change_msg_created.php" style="color:#fff;">Change Message</a>
				</div>
				<input type="hidden" id="private" name="rowvalue" value="" />
				<input type="submit" onclick="return confirm('Do u want to Send Request Message Selected Teacher Create Course?');" class="btn btn-primary pull-right delete_all" title="Send Message" name="submitDelete" value="Send Message">
			</span>
                
			<table id="example" class="display" cellspacing="0" width="100%">
			<thead>
				<tr>
				    <th>
                          <input type="checkbox"  id="master">
                         
					</th>
				    <th>UserName</th>
					<th>Name</th>
					<th>Email</th>
					<th>Languages Speak </th>
					<th>Languages Teach </th>
					<th>Role</th>
					<th>Date of Registration</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			    global $wpdb;
				$argse = array('role' => 'editor');
				//Teacher query
				$editoruser = get_users( $argse );
				
				$getteacher = count( get_users( $argse ) );			
				for($i=0 ; $i < $getteacher; $i++)
				{
					global $wpdb;
					$mycourse = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_courses where created_by = '".$editoruser[$i]->ID."'");
					if(count($mycourse) != 0){
					$status = get_user_meta($editoruser[$i]->ID, account_status,false);
					   $inactive = 0;
						for($n=0 ; $n < count($status);$n++){
						   if(strcmp($status[$n], 'inactive') == 0)
						   {
							 $inactive = 1;
						   }
						}
					if($inactive == 0){
					$emailtech = get_userdata($editoruser[$i]->ID); 
					$emaillang = get_user_meta($editoruser[$i]->ID,'languages',true);
					$emailteach = get_user_meta($editoruser[$i]->ID,'languages2',true);
					if(!empty($emaillang)){
						$speacklanguage = implode(',', $emaillang);
					}
					else{
						$speacklanguage = '';
					}
                    if(!empty($emailteach)){
						$teachlanguage = implode(',', $emailteach);	
					}
					else{
						$teachlanguage = '';
					}
				?>
				<tr data-row-id="<?= $emailtech->ID; ?>">
				    <td><div id="geton"><input type="checkbox" class="sub_chk" data-id="<?= $emailtech->ID; ?>" name="selecttodelete"></div></td>
					<td><?= $emailtech->user_login; ?></td>
					<td><?= $emailtech->display_name; ?></td>
					<td><?= $emailtech->user_email; ?></td>
					<td><?= $speacklanguage; ?></td>
					<td><?= $teachlanguage; ?></td>
					<td><?php if($emailtech->roles[0] == 'editor') echo 'Teacher';?></td>
					<td><?= $emailtech->user_registered; ?></td>			
				</tr>
					<?php } }
                    				
				} ?>
			</tbody>
				<tfoot>
				  <tr>
					 <th></th>
					 <th>UserName</th>
					 <th>Name</th>
					 <th>Email</th>
					 <th>Languages Speak </th>
					 <th>Languages Teach </th>
					 <th>Role</th>
					 <th>Date of Registration</th>
				  </tr>
			   </tfoot>
			</table>
		   </form>	
		</div><!-- .entry-content -->
	</article><!-- #post-## -->
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript">
	  $(document).ready(function() {
		$('#example').DataTable({
			"order": [],
    "columnDefs": [ {
      "targets"  : 'no-sort',
      "orderable": false,
    }],"bSort" : false,"aaSorting" : [[]]
		});
	  });
	</script>
	<script>
	/*$(document).ready(function() {

    var $selectAll = $('.selectAll'); // main checkbox inside table thead
    var $table = $('.display'); // table selector
    var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
    var $tdCheckboxChecked = []; // checked checbox arr

    //Select or deselect all checkboxes on main checkbox change
    $selectAll.on('click', function () {
        $tdCheckbox.prop('checked', this.checked);
    });
    //Switch main checkbox state to checked when all checkboxes inside tbody tag is checked
    $tdCheckbox.on('change', function(){
        $tdCheckboxChecked = $table.find('tbody input:checkbox:checked');//Collect all checked checkboxes from tbody tag
        //if length of already checked checkboxes inside tbody tag is the same as all tbody checkboxes length, then set property of main checkbox to "true", else set to "false"
        $selectAll.prop('checked', ($tdCheckboxChecked.length == $tdCheckbox.length));
    })

    $($selectAll).on('ifChanged', function(event){
      console.log($tdCheckbox.val());
         if(!this.changed) {
             this.changed=true;
      
         } else {
             this.changed=false;
 
         }

    });
});*/
jQuery('#master').on('click', function(e) {
    if($(this).is(':checked',true))  
    {
        $(".sub_chk").prop('checked', true);  
    }  
    else  
    {  
        $(".sub_chk").prop('checked',false);  
    }  
});
</script>
<script>
jQuery('.delete_all').on('click', function(e) { 
var allVals = [];  
        $(".sub_chk:checked").each(function() {  
            allVals.push($(this).attr('data-id'));
        });  
        if(allVals.length <=0)  
        {  
            alert("Please select row.");  
        }  
        else {  
            //$("#loading").show(); 
            //WRN_PROFILE_DELETE = "Do u want to Send Request Message Selected Teacher Create Course?";  
            //var check = confirm(WRN_PROFILE_DELETE);  
           
                //for server side
                var join_selected_values = allVals.join(","); 
               //alert(join_selected_values);
				$("#private").val(join_selected_values);
                /*$.ajax({   
                  
                    type: "POST",  
                    url: "?page=send_message.php",  
                    cache:false,  
                    data: 'ids='+join_selected_values,  
                    success: function(response)  
                    {   
                        $("#loading").hide();
alert(response);						
                        $("#msgdiv").html(response);
                        //referesh table
                    }   
                });*/
              //for client side
              /*$.each(allVals, function( index, value ) {
                  $('#private').add("[value='" + value + "']");
              });*/
                

           
        }  
    });
</script>
	