<?php
echo '<div class= "wrap" >'; 
echo '<h2>Change Message</h2>';
require_once('../wp-config.php');
require_once('../AuthBase.php');
global $wpdb;

	if(isset($_POST['submit']))
	{
                 global $wpdb;
                 $table_names = $wpdb->prefix . "ext_page";
		$page_update =  $wpdb->update($table_names, array(
						'page_name'  =>  $_POST['page_name'],
						'Description'  =>  str_replace('\"', '"', $_POST['editor1'])						
		),array('ID' => 4)); 
		//On success
		if ( ! is_wp_error( $page_update ) ) {
                       
			echo "<script>alert('successfully change msg')</script>";
			 echo "<script>window.location='?page=teacher_created_course.php'</script>"; 
			
		}
    }
	
		global $wpdb;
		$results = $wpdb->get_results("select * from ".$wpdb->prefix ."ext_page where id ='4'");
?>
        

	<?php 
	/* Template Name: Claims and Disputes */ 
	global $wpdb;
	?>
          <style>
				.input-sm {
				  height: 30px;
				  padding: 5px 10px;
				  font-size: 12px;
				  line-height: 1.5;
				  border-radius: 3px;
				  width:40%;
				}

				select.input-sm {
				  height: 30px;
				  line-height: 30px;
				}

				textarea.input-sm {
				  height: auto;
				}

				.input-lg {
				  height: 30px;
				  padding: 5px 10px;
				  font-size: 12px;
				  line-height: 1.5;
				  border-radius: 3px;
				  width:100%;
				}
				select{
					height:20px;
				}
				.btn {
				display: inline-block;
				padding: 9px 12px;
				padding-top: 6px;
				margin-bottom: 0;
				font-size: 13px;
				line-height: 16px;
				color: #5e5e5e;
				text-align: center;
				vertical-align: middle;
				cursor: pointer;
				background-color: #d1dade;
				-webkit-border-radius: 3px;
				-webkit-border-radius: 3px;
				-webkit-border-radius: 3px;
				background-image: none !important;
				border: none;
				text-shadow: none;
				box-shadow: none;
				transition: all 0.12s linear 0s !important;
				font: 13px/13px "Helvetica Neue",Helvetica,Arial,sans-serif;
				}
					
				.btn-success {
				color: #fff;
				background-color: #5cb85c;
				border-color: #4cae4c;
				}
					
				.btn-danger {
				color: #fff;
				background-color: #d9534f;
				border-color: #d43f3a;
				}
				</style>
				<?php if(isset($_GET['msg'])){ 
				  echo 'Alert ! <b>'.$_GET['msg'].'?</b>';
				}?>
		<script src="//cdn.ckeditor.com/4.5.10/full/ckeditor.js"></script>	
		<form class="form-horizontal" action="" method="POST" role="form">
            <div class="form-group"> <label class="control-label col-sm-2" for="class_name">&nbsp;</label>
              <div class="col-sm-10">
                <h2>Teacher Created Course Message</h2>
              </div>
            </div>

           <div class="form-group">
              <label class="control-label col-sm-2" for="lang_name">Subject<span class="um-req" title="Required">*</span> :</label>
              <div class="col-sm-12">
                <input type="text" class="input-lg"  name="page_name" id="page_name" placeholder="Enter Page Name" value='<?= $results[0]->page_name; ?>'>
              </div>
            </div>
			
			<div class="form-group">
              <label class="control-label col-sm-2" for="short_name">Message<span class="um-req" title="Required"></span> :</label>
              <div class="col-sm-10">
				<textarea class="ckeditor" name="editor1" rows="10"  cols="60"><?= $results[0]->Description; ?></textarea>
					<script>
						CKEDITOR.replace( 'editor1' );
					</script>
              </div>
            </div>
			<div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success" name="submit" id="submit" value="Submit">
              </div>
            </div>
          </form>
				
  
<?php echo '</div>'; ?>

