<?php
/**
 * Plugin Name: Admin Menu
 * Description: Custom Admin Menu.
 * Plugin URI: http://wordsandvideos.com/
 * Author: Pravin Shrikhande
 * Author URI: http://wordsandvideos.com/
 */

/**
 * Hide default welcome dashboard message and and create a custom one
 *
 * @access      public
 * @since       1.0 
 * @return      void
*/
function rc_my_welcome_panel() { ?>

					<?php 
					global $wpdb;
					//echo '<pre>';
                   //print_r($GLOBALS['wp_scripts']);
					$getuser = $wpdb->get_results("select * from ".$wpdb->prefix."users");
					
						global $wpdb;
						$args = array('role' => 'subscriber');
						// The Query
						$getstudent = count( get_users( $args ) );
						


						$argse = array('role' => 'editor');
						//Teacher query
						$getteacher = count( get_users( $argse ) );
						
						global $wpdb;
				        $todaydate=date('Y-m-d');
						$timetoday = $todaydate.' '.'00:00:00';
						$endtime = $todaydate.' '.'23:59:59';
						$todayresult = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_wclasses where Class_status = '0' and class_time >= '".$timetoday."' and class_time <= '".$endtime."'");
$todaycorporesult = $wpdb->get_results("select * from ".$wpdb->prefix ."wclasses_corporates where class_time >= '".$timetoday."' and class_time <= '".$endtime."'");
					?>
	<script type="text/javascript">
		// Hide default welcome message
		jQuery(document).ready( function($) {
			$('div.welcome-panel-content').show();
		});
	</script>
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<style>
		.row {
		  margin-right: -15px;
		  margin-left: -15px;
		}
		.col-lg-3,.col-sm-6{
			  position: relative;
			  min-height: 1px;
			  padding-right: 2px;
			  padding-left: 2px;
			}
			   .col-lg-3 {
				width: 20%;
			  }
			  .col-sm-6 {
				width: 20%;
			  }
			  .panel {
			  margin-bottom: 20px;
			  background-color: #ffffff;
			  border: 1px solid transparent;
			  border-radius: 4px;
			  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
					  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
			}
			.panel {
			  margin-bottom: 0;
			  overflow: hidden;
			  border-radius: 4px;
			}
			.panel {
			  margin-top: 5px;
			}
			 section
			 {
			  display: block;
			}
			.dashicons.custom-dashicon {
				font-size: 75px;
			}
			.value h1 {
				font-weight: 300;
				text-align:center;
				padding-left:50px;
			}
			.value p {
				text-align:center;
				padding-left:40px;
			}
			.state-overview .terques .value{
				background: #6ccac9;
			}
			.terques {
				background: #6ccac9;
			}

			.red {
				background: #ff6c60;
			}

			.yellow {
				background: #f8d347;
			}

			.blue {
				background: #57c8f2;
			}
                        .col-md-12{
				width:100%;
			}
                        .orange{
                          background: #ef2058; 
                            }

	</style>
	      <!--state overview start-->
             <table width="100%" cellpadding="0px" cellspacing="0px">
			  <tr>
                  <td class="col-lg-3">
                      <a href="users.php">
                      <div class="panel">
                          <div class="symbol terques">
                              <span class="dashicons dashicons-businessman custom-dashicon"></span>
                          </div>
                          <div class="value">
                              <h1 class="count">
                                  <?=count($getuser);?>
                              </h1>
                              <p>Users</p>
                          </div>
                      </div>
                      </a>
                  </td>
                  <td class="col-lg-3">
					  <a href="users.php?role=subscriber">
                      <div class="panel">
                          <div class="symbol red">
                              <span class="dashicons dashicons-groups custom-dashicon"></span>
                          </div>
                          <div class="value">
                              <h1 class=" count2">
                                  <?=$getstudent;?>
                              </h1>
                              <p>Students</p>
                          </div>
                      </div>
					  </a>
                  </td>
                  <td class="col-lg-3">
				      <a href="users.php?role=editor">
                      <div class="panel">
                          <div class="symbol yellow">
                              <span class="dashicons dashicons-id-alt custom-dashicon"></span>
                          </div>
                          <div class="value">
                              <h1 class=" count3">
                                  <?=$getteacher;?>
                              </h1>
                              <p>Teachers</p>
                          </div>
                      </div>
					  </a>
                  </td>
                  <td class="col-lg-3">
				  <a href="admin.php?page=wiziq_liveclass">
                      <div class="panel">
                          <div class="symbol blue">
                             <span class="dashicons dashicons-calendar-alt custom-dashicon"></span>
                          </div>
                          <div class="value">
                              <h1 class=" count4">
                                  <?=count($todayresult);?>
                              </h1>
                              <p>Today Classes</p>
                          </div>
                      </div>
					  </a>
				   </td>	
                  <td class="col-lg-3">
					  <a href="admin.php?page=wiziq_corporates&todaycorpclass=1">
                      <div class="panel">
                          <div class="symbol orange">
                             <span class="dashicons dashicons-welcome-learn-more custom-dashicon"></span>
                          </div>
                          <div class="value">
                              <h1 class=" count4">
                                  <?=count($todaycorporesult);?>
                              </h1>
                              <p>Today Corporates Classes</p>
                          </div>
                      </div>
					  </a>
				   </td>	  
                  </tr>
              </table>
	<div class="custom-welcome-panel-content">
	<h3><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3>
	<p class="about-description"><br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;</p>
	
	</div><!-- .custom-welcome-panel-content -->
	          <!--<script src="../jquery.js"></script>-->
			  <script>
			  /*function countUp(count)
					{
						var div_by = 100,
							speed = Math.round(count / div_by),
							$display = $('.count'),
							run_count = 1,
							int_speed = 24;

						var int = setInterval(function() {
							if(run_count < div_by){
								$display.text(speed * run_count);
								run_count++;
							} else if(parseInt($display.text()) < count) {
								var curr_count = parseInt($display.text()) + 1;
								$display.text(curr_count);
							} else {
								clearInterval(int);
							}
						}, int_speed);
					}
                    
					countUp(<?=count($getuser);?>);

					function countUp2(count)
					{
						var div_by = 100,
							speed = Math.round(count / div_by),
							$display = $('.count2'),
							run_count = 1,
							int_speed = 24;

						var int = setInterval(function() {
							if(run_count < div_by){
								$display.text(speed * run_count);
								run_count++;
							} else if(parseInt($display.text()) < count) {
								var curr_count = parseInt($display.text()) + 1;
								$display.text(curr_count);
							} else {
								clearInterval(int);
							}
						}, int_speed);
					}

					countUp2(947);

					function countUp3(count)
					{
						var div_by = 100,
							speed = Math.round(count / div_by),
							$display = $('.count3'),
							run_count = 1,
							int_speed = 24;

						var int = setInterval(function() {
							if(run_count < div_by){
								$display.text(speed * run_count);
								run_count++;
							} else if(parseInt($display.text()) < count) {
								var curr_count = parseInt($display.text()) + 1;
								$display.text(curr_count);
							} else {
								clearInterval(int);
							}
						}, int_speed);
					}

					countUp3(328);

					function countUp4(count)
					{
						var div_by = 100,
							speed = Math.round(count / div_by),
							$display = $('.count4'),
							run_count = 1,
							int_speed = 24;

						var int = setInterval(function() {
							if(run_count < div_by){
								$display.text(speed * run_count);
								run_count++;
							} else if(parseInt($display.text()) < count) {
								var curr_count = parseInt($display.text()) + 1;
								$display.text(curr_count);
							} else {
								clearInterval(int);
							}
						}, int_speed);
					}

					countUp4(10328);*/
			  </script>
              <!--state overview end-->
<?php
}
add_action( 'welcome_panel', 'rc_my_welcome_panel' ); ?>
<?php 
add_action( 'admin_menu', 'no_create_course' );
function no_create_course() {
	add_menu_page(__('Teachers Not Created Course','menu-test'), __('Teachers Not Created Course','menu-test'), 'manage_options', 'user_no_create_course.php', 'user_course_no_create', 'dashicons-thumbs-down', 70 );
}
/*
 * Function to wiziq_reports
 */ 
function user_course_no_create () {
	require_once( 'user_no_create_course.php' );
}
?>
<?php 
	add_action( 'admin_menu', 'change_mail' );
	function change_mail() {
		// Add a submenu to the custom top-level menu:
		add_submenu_page( '', '', __('Change Message', 'menu-test'), 'manage_options', 'Change_msg.php', 'onFunc' ); 

	}
	/*
	 * Function to wiziq_reports
	 */
			function onFunc() {
			require_once( 'Change_msg.php' );
		} 
?>
<?php 
add_action( 'admin_menu', 'no_book_course' );
function no_book_course() {
	add_menu_page(__('Students Not Booked Course','menu-test-book'), __('Students Not Booked Course','menu-test-book'), 'manage_options', 'user_no_book_course.php', 'user_course_no_book', 'dashicons-thumbs-down', 70 );
}
/*
 * Function to wiziq_reports
 */ 
function user_course_no_book () {
	require_once( 'user_no_book_course.php' );
}
?>
<?php 
	add_action( 'admin_menu', 'change_mail_student' );
	function change_mail_student() {
		// Add a submenu to the custom top-level menu:
		add_submenu_page( '', '', __('Change Message', 'menu-test-book'), 'manage_options', 'Change_msg_student.php', 'onFuncstudent' ); 

	}
	/*
	 * Function to wiziq_reports
	 */
			function onFuncstudent() {
			require_once( 'Change_msg_student.php' );
		} 
		add_action('admin_menu','ccavenue_wordsand');
		function ccavenue_wordsand(){
			add_menu_page( __('ccavenue_page', 'menu_ccavenue'), __('Ccavenue Details','menu_ccavenue'),'manage_options','menu_ccavenue','ccavenue_wav','dashicons-tickets',160);
		}
		function ccavenue_wav(){
			require_once('ccavenue_wav.php');
		}
?>
<?php 
add_action( 'admin_menu', 'teacher_create_course' );
function teacher_create_course() {
	add_menu_page(__('Teachers Created Course','menu-test'), __('Teachers Created Course','menu-test'), 'manage_options', 'teacher_created_course.php', 'user_course_create', 'dashicons-thumbs-up', 100 );
}
/*
 * Function to wiziq_reports
 */ 
function user_course_create () {
	require_once( 'teacher_created_course.php' );
}
?>
<?php 
	add_action( 'admin_menu', 'change_created_mail' );
	function change_created_mail() {
		// Add a submenu to the custom top-level menu:
		add_submenu_page( '', '', __('Change Message', 'menu-test'), 'manage_options', 'change_msg_created.php', 'createdFunc' ); 

	}
	/*
	 * Function to wiziq_reports
	 */
			function createdFunc() {
			require_once( 'change_msg_created.php' );
		} 
?>
<?php 
add_action( 'admin_menu', 'Student_book_course' );
function Student_book_course() {
	add_menu_page(__('Students Booked Course','menu-test-book'), __('Students Booked Course','menu-test-book'), 'manage_options', 'student_booked_course.php', 'user_course_book', 'dashicons-thumbs-up', 100 );
}
/*
 * Function to wiziq_reports
 */ 
function user_course_book () {
	require_once( 'student_booked_course.php' );
}
add_action( 'admin_menu', 'mail_booked_student' );
	function mail_booked_student() {
		// Add a submenu to the custom top-level menu:
		add_submenu_page( '', '', __('Change Message', 'menu-test-book'), 'manage_options', 'change_msg_booked.php', 'onFuncbooked' ); 

	}
	/*
	 * Function to wiziq_reports
	 */
			function onFuncbooked() {
			require_once( 'change_msg_booked.php' );
		} 
?>